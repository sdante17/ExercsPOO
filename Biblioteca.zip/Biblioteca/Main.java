package Biblioteca;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    private static Biblioteca biblioteca = new Biblioteca();
    private static ArrayList<Livro> livros = new ArrayList<>();
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("====== Bem vindo ao sistema da Biblioteca ======");
        while(true) {
            System.out.println("Selecione a opcao desejada:");
            System.out.println("1 - Cadastrar livro\t2 - Listar livros cadastrados");
            System.out.println("3 - Emprestimo de livro\t4 - Devolucao de livro");
            System.out.println("x - Para sair");
            String op = sc.nextLine();

            if (op.equalsIgnoreCase("x")) {
                break;
            }

            switch (op) {
                case "1":
                    System.out.print("Digite o nome do exemplar: ");
                    String titulo = sc.nextLine();
                    
                    System.out.print("Digite o autor da obra: ");
                    String autor = sc.nextLine();

                    System.out.print("Digite o codigo: ");
                    String isbn = sc.nextLine();

                    Livro livro = new Livro();

                    livro.setTitulo(titulo);
                    livro.setAutor(autor);
                    livro.setIsbn(isbn);

                    biblioteca.addLivro(livro);
                    System.out.println("Livro cadastrado com sucesso!");

                    break;

                case "2":
                    biblioteca.listarLivros();
                    break;

                case "3":
                    System.out.print("Digite o isbn do livro: ");
                    String id = sc.nextLine();

                    biblioteca.emprestarLivro(id);

                    break;

                case "4":
                    System.out.print("Digite o isbn do livro: ");
                    String id2 = sc.nextLine();

                    biblioteca.devolverLivro(id2);

                    break;
            
                default:
                    System.err.println("Opcao invalida!");
                    break;
            }
        }

        sc.close();
        System.out.println("Encerrando programa...");
    }
}