package Biblioteca;

import java.util.ArrayList;

public class Biblioteca {
    private ArrayList<Livro> livros;

    public Biblioteca() {
        livros = new ArrayList<>();
    }

    public void addLivro(Livro livro) {
        livros.add(livro);
    }

    public void listarLivros() {
        if(livros.isEmpty()){
            System.err.println("Biblioteca vazia!");
            return;
        }
        
        System.out.println("===== Livros cadastradas na Biblioteca =====");
        for (Livro l : livros) {
            System.out.println("ISBN: " + l.getIsbn() + " - Nome: " + l.getTitulo() + " - Autor: " + l.getAutor() + " - " + (l.isDisponivel() == true ? "Disponivel" : "Alugado"));
        }
    }

    public void emprestarLivro(String isbn) {
        boolean found = false;

        if(livros.isEmpty()){
            System.err.println("Biblioteca vazia!");
            return;
        }

        for (Livro l : livros) {
            if(l.getIsbn().equalsIgnoreCase(isbn)){
                found = true;
                System.out.println("Livro encontrado!");
                if(l.isDisponivel()){
                    l.setDisp(false);
                    System.out.println("Emprestimo concluido!");
                    System.out.println("A Biblioteca agradece a preferencia...");
                } else {
                    System.err.println("Livro ja emprestado!");
                }
                break;
            }

            if(!found) {
                System.err.println("Livro nao encontrado!");
            }
        }
    }

    public void devolverLivro(String isbn) {
        boolean found = false;

        if(livros.isEmpty()){
            System.err.println("Biblioteca vazia!");
            return;
        }

        for (Livro l : livros) {
            if(l.getIsbn().equalsIgnoreCase(isbn)){
                found = true;
                System.out.println("Livro encontrado!");
                if(!l.isDisponivel()){
                    l.setDisp(true);
                    System.out.println("Devolucao concluida!");
                    System.out.println("A Biblioteca agradece a preferencia...");
                } else {
                    System.err.println("Livro ja se apresentava disponivel...");
                }
                break;
            }

            if(!found) {
                System.err.println("Livro nao encontrado!");
            }
        }
    }
}