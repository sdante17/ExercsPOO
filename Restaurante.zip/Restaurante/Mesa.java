package Restaurante;

public class Mesa {
	private int num;
	
	public Mesa(int num) {
		this.num = num;
	}
	
	public int getNum() {
		return this.num;
	}
	
	public void setNum(int n) {
		this.num = n;
	}

}