package Restaurante;

import java.util.ArrayList;

public class Prato {
    private String nome;
    private double preco;
    private ArrayList<String> ingredientes = new ArrayList<>();
    private DiaSemana disponibilidade;

    public Prato() {
        
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
    public double getPreco() {
        return preco;
    }

    public void setPreco(Double preco) {
        this.preco = preco;
    }

    public ArrayList<String> getIngredientes() {
        return ingredientes;
    }

    public void addIngrediente(String ingrediente) {
        ingredientes.add(ingrediente);
    }

    public DiaSemana getDisponibilidade() {
        return disponibilidade;
    }

    public void setDisponibilidade(DiaSemana disponibilidade) {
        this.disponibilidade = disponibilidade;
    }
}