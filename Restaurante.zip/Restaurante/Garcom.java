package Restaurante;

public class Garcom extends Pessoa {
    private Regiao regiao;

    public Garcom(String nome){
        super(nome);
    }

    public String getRegiao() {
        return regiao;
    }

    public void setRegiao(String regiao) {
        this.regiao = regiao;
    }
}