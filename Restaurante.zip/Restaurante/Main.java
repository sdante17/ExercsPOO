package Restaurante;

import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;

public class Main {
    private static Cardapio cardapio = new Cardapio();
    private static List<Pedido> pedidos = new ArrayList<>();

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("Selecione a opção desejada:");
            System.out.println("1 - Adicionar prato ao cardapio\t2 - Listar pratos do cardapio");
            System.out.println("3 - Fazer pedido\t4 - Listar Pedidos\t5 - Concluir um pedido");
            System.out.println("x - Sair");

            String op = sc.nextLine();

            if (op.equalsIgnoreCase("x")) {
                break;
            }

            switch (op) {
                case "1":
                    Prato prato = new Prato();

                    System.out.print("Nome do prato: ");
                    String nome = sc.nextLine();

                    System.out.print("Preco do prato: ");
                    double preco = sc.nextDouble();
                    sc.nextLine();

                    System.out.println("Domingo = 0, Segunda = 1, ..., Sabado = 6");
                    System.out.println("O prato estara disponivel em qual dia? ");
                    int diaIndex = sc.nextInt();
                    sc.nextLine();
                    DiaSemana disponibilidade = DiaSemana.values()[diaIndex];

                    System.out.print("Quantos ingredientes este prato vai possuir? ");
                    int temp = sc.nextInt();
                    sc.nextLine();

                    for(int i = 0; i < temp; i++){
                        System.out.print(i + 1 + "° ingrediente: ");
                        String ingrediente = sc.nextLine();
                        prato.addIngrediente(ingrediente);
                    }

                    prato.setNome(nome);
                    prato.setPreco(preco);
                    prato.setDisponibilidade(disponibilidade);

                    cardapio.addPrato(prato);
                    System.out.println("Prato adicionado ao cardapio!");
                    break;

                case "2":
                    System.out.println("Pratos do cardapio:");
                    cardapio.listarPratos();
                    break;

                case "3":
                    System.out.println("Criando pedido...");
                	System.out.print("Digite o nome do prato: ");
                    String nomep = sc.nextLine();
                    Prato selectp = null;
                    
                    for (Prato p : cardapio.getNomePrato()) {
                        if (p.getNome().equalsIgnoreCase(nomep)) {
                            selectp = p;
                            break;
                        }
                    }
                    
                    if (selectp == null) {
                        System.out.println("Prato nao encontrado!");
                        break;
                    }

                    System.out.print("Nome do cliente: ");
                    String nomeCliente = sc.nextLine();

                    System.out.println("Se foi atendido em uma mesa, digite o numero da mesa.");
                    System.out.print("Se o pedido foi feito online, digite 0: ");
                    int mesaNum = sc.nextInt();
                    sc.nextLine();

                    String horarioAgend = null;

                    Pedido pedido = new Pedido();

                    if(mesaNum == 0){
                        System.out.print("Endereco: ");
                        pedido.setEndereco(sc.nextLine());
                        
                        System.out.println("Caso queira agendar um horario para o pedido, digite a hora.");
                        System.out.print("Se não, apenas pule: ");
                        horarioAgend = sc.nextLine();

                        if(horarioAgend.isEmpty()) {
                            System.out.println("Pedido sera atendido imediatamente!");
                        } else {
                            pedido.setHora(horarioAgend);
                            System.out.println("Pedido agendado para o horario: " + pedido.getHora());
                        }

                    } else if (mesaNum > 0){
                        pedido.setMesa(new Mesa(mesaNum));
                    } else {
                        System.out.println("Numero de mesa invalido...");
                        break;
                    }

                    pedido.setPrato(selectp);
                    pedido.setCliente(new Cliente(nomeCliente));

                	pedidos.add(pedido);
                    System.out.println("Pedido realizado com sucesso!");
                    break;
                    
                case "4":
                    System.out.println("Listando todos os pedidos:");
                    if (pedidos.isEmpty()) {
                        System.out.println("Nenhum pedido foi criado ainda.");
                    } else {
                        for (Pedido ped : pedidos) {
                            String mesaInfo = (ped.getMesa() == null ? "Pedido online" : "Mesa " + ped.getMesa().getNum());
                            System.out.println("| Pedido: " + ped.getId() + "| Prato: " + ped.getPrato().getNome() + "| " + mesaInfo + "| Horario: " + (ped.getHora() == null ? "imediato" : ped.getHora()) + "| " + ped.getStatus());
                        }
                    }
        
                    break;
                	
                case "5":
                    boolean found = false;

                    System.out.print("Digite o id do pedido: ");
                    int id = sc.nextInt();
                    sc.nextLine();

                    for (Pedido p : pedidos) {
                        if (id == p.getId()) {
                            found = true;
                            p.atenderPedido();
                            System.out.println("Pedido: " + id + " - concluido!");
                            break;
                        }
                    }
                    if(!found){
                        System.out.println("Pedido nao encontrado...");
                    }

                    break;
               
                default:
                    System.out.println("Opcao invalida!");
                    break;
            }
        }

        sc.close();
        System.out.println("Encerrando o programa...");
    }
}