package Restaurante;

import java.util.ArrayList;
import java.util.List;

public class Cardapio {
    private ArrayList<Prato> pratos;

    public Cardapio() {
        this.pratos = new ArrayList<>();
    }
    
    public void addPrato(Prato prato) {
        pratos.add(prato);
    }

    public List<Prato> getNomePrato() {
        return pratos;
    }    

    public void listarPratos() {
        if(pratos.isEmpty()) {
            System.out.println("Cardapio vazio...");
            return;
        }

        for (Prato prato : pratos) {
            System.out.println(prato.getNome() + " - R$ " + prato.getPreco() + " - Disponivel na " + prato.getDisponibilidade());

            if(!prato.getIngredientes().isEmpty()) {
                System.out.print("Ingredientes: ");
                for(String ingrediente : prato.getIngredientes()) {
                    System.out.print(ingrediente + ", ");
                }
                System.out.println();
            } else {
                System.out.println("Sem ingredientes...");
            }
        }
    }
}