package Restaurante;

public class Cliente extends Pessoa {
    private String contato;

    public Cliente(String nome) {
        super(nome);
    }

    public String getContato() {
        return contato;
    }

    public void setContato(String contato) {
        this.contato = contato;
    }
}