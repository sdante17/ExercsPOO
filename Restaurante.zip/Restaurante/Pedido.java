package Restaurante;

public class Pedido {
    private int id;
    private static int idAuto = 1;
    private Prato prato;
    private Cliente cliente;
    private Mesa mesa;
    private String enderEntrega;
    private String horarioAgend;
    private boolean status;

    public Pedido() {
        this.id = idAuto++;
        this.status = false;
    }

    public int getId() {
        return id;
    }    
    
    public Prato getPrato() {
        return prato;
    }
    
    public void setPrato(Prato prato) {
        this.prato = prato;
    }

    public Cliente getCliente() {
        return cliente;
    }
    
    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }
    
    public Mesa getMesa() {
        return mesa;
    }
    
    public void setMesa(Mesa mesa) {
        this.mesa = mesa;
    }    

    public String getEndereco() {
        return enderEntrega;
    }
    
    public void setEndereco(String endereco) {
        this.enderEntrega = endereco;
    }
    
    public String getHora() {
        return horarioAgend;
    }
    
    public void setHora(String h) {
    	this.horarioAgend = h;
    }

    public String getStatus() {
        return this.status ? "Concluido" : "Em andamento";
    }    

    public void atenderPedido() {
        this.status = true;
    }
}