package Restaurante;

public class Telefonista extends Pessoa {
    private String contato;

    public Telefonista(String nome) {
        super(nome);
    }

    public String getContato(){
        return contato;
    }

    public void setContato(String contato){
        this.contato = contato;
    }
}