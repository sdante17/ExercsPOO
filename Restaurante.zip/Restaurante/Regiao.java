package Restaurante;

import java.util.ArrayList;

public class Regiao {
    private String nome;
    private ArrayList<Garcom> garcons;

    public Regiao(){
        this.garcons = new ArrayList<>();
    }

    public void adicionarGarcom(Garcom garcom) {
        if (!garcons.contains(garcom)) {
            garcons.add(garcom);
        }
    }    
}
