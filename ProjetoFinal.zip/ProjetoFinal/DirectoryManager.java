package ProjetoFinal;

import java.io.File;

public class DirectoryManager {

    private String currentDirectory = System.getProperty("user.dir");

    public void pwd() {
        System.out.println(currentDirectory);
    }

    public void ls() {
        File dir = new File(currentDirectory);
        String[] files = dir.list();
        if (files != null) {
            for (String file : files) {
                System.out.println(file);
            }
        }
    }

    public void cd(String path) {
        File newDir = new File(currentDirectory + File.separator + path);
        if (newDir.exists() && newDir.isDirectory()) {
            currentDirectory = newDir.getAbsolutePath();
        } else {
            System.out.println("Diretório não encontrado: " + path);
        }
    }

    public void mkdir(String dirName) {
        File newDir = new File(currentDirectory + File.separator + dirName);
        if (!newDir.exists()) {
            newDir.mkdir();
        } else {
            System.out.println("Diretório já existe: " + dirName);
        }
    }
}
