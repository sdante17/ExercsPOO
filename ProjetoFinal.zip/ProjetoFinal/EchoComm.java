package ProjetoFinal;

public class EchoComm extends CommandHandler {
    private final FileManager fileManager;

    public EchoComm(FileManager fileManager) {
        this.fileManager = fileManager;
    }

    @Override
    public void execute(String[] args) {
        if (args.length < 3 || !args[args.length - 2].equals(">")) {
            System.out.println("Uso: echo <texto> > <arquivo>");
            return;
        }

        // Junta o texto (tudo entre o primeiro argumento e o ">")
        StringBuilder texto = new StringBuilder();
        for (int i = 0; i < args.length - 2; i++) {
            texto.append(args[i]).append(" ");
        }
        String textoFinal = texto.toString().trim(); // Remove espaços extras

        // Pega o nome do arquivo (último argumento)
        String arquivo = args[args.length - 1];

        fileManager.echo(textoFinal, arquivo);
    }
}
