package ProjetoFinal;

abstract public class CommandHandler {
    public abstract void execute(String[] args);
}