package Aeroporto;

class Aeromoca {
    private String nome;

    public Aeromoca(String nome) {
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }
}