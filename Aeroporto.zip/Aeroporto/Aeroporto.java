package Aeroporto;

import java.util.ArrayList;
import java.util.List;

public class Aeroporto {
    private List<Voo> voos;

    public Aeroporto() {
        this.voos = new ArrayList<>();
    }

    public void adicionarVoo(Voo voo) {
        voos.add(voo);
    }

    public void listarVoos() {
        System.out.println("Voos no Aeroporto:");
        for (Voo voo : voos) {
            System.out.println("Voo " + voo.getNumero() + " - " + (voo.getStatus() == false ? "Decolando" : "Aterrissando"));
        }
    }
}