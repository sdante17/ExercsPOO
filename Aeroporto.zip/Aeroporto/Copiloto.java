package Aeroporto;

class CoPiloto {
    private String nome;

    public CoPiloto(String nome) {
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }
}