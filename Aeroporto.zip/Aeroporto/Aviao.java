package Aeroporto;

import java.util.ArrayList;
import java.util.List;

public class Aviao {
    private String modelo;
    private int numLugares;
    private List<Passageiro> lugares;

    public Aviao(String modelo, int numLugares) {
        this.modelo = modelo;
        this.numLugares = numLugares;
        this.lugares = new ArrayList<>();
        for (int i = 0; i < numLugares; i++) {
            lugares.add(null);
        }
    }

    public void ocuparLugar(int lugar, Passageiro passageiro) {
        if (lugar >= 0 && lugar < numLugares && lugares.get(lugar) == null) {
            lugares.set(lugar, passageiro);
            System.out.println(passageiro.getNome() + " foi alocado no assento " + lugar);
        } else {
            System.out.println("Assento inválido");
        }
    }

    public void listarOcupantes() {
        for (int i = 0; i < lugares.size(); i++) {
            if (lugares.get(i) != null) {
                System.out.println("Assento " + i + ": " + lugares.get(i).getNome());
            }
        }
    }
}