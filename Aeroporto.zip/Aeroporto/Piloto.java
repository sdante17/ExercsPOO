package Aeroporto;

class Piloto {
    private String nome;

    public Piloto(String nome) {
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }
}