package Aeroporto;

public class Voo {
    private int numVoo;
    private String horario;
    private boolean status; // "Decolando" ou "Aterrissando"
    private Aviao aviao;
    private Tripulacao tripulacao;

    public Voo(int numVoo, String horario, Aviao aviao, Tripulacao tripulacao) {
        this.numVoo = numVoo;
        this.horario = horario;
        this.status = false;
        this.aviao = aviao;
        this.tripulacao = tripulacao;
    }

    public int getNumero() {
        return this.numVoo;
    }

    public boolean getStatus() {
        return this.status;
    }

    public void aterrissar(){
        this.status = true;
    }

    public void listarPassageiros() {
        System.out.println("Passageiros no voo " + this.numVoo + ":");
        aviao.listarOcupantes();
    }
}