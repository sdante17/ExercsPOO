package Aeroporto;

import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;

public class Main {
    private static Aeroporto aeroporto = new Aeroporto();
    private static List<Voo> voos = new ArrayList<>();
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Bem vindo ao sistema do Aeroporto!");
        while(true){
            System.out.println("Escolha a opcao desejada: ");
            System.out.println("1 - Cadastro da tripulacao\t2 - Cadastrar aviao\t3 - Adicionar passagueiro");
            System.out.println("4 - Adicionar vooz\t5 - Listar voos\t6 - Editar status de voo");
            System.out.println("7 - Listar tripulacao e passagueiros do vooz\tx - Para sair");
            int op = sc.nextInt();
            sc.nextLine();

            switch (op) {
                case '1':
                    System.out.print("Digite o nome do piloto: ");
                    String nomePiloto = sc.nextLine();
                    Piloto piloto = new Piloto(nomePiloto);
            
                    System.out.print("Digite o nome do co-piloto: ");
                    String nomeCoPiloto = sc.nextLine();
                    CoPiloto coPiloto = new CoPiloto(nomeCoPiloto);

                    Tripulacao tripulacao = new Tripulacao(piloto, coPiloto);

                    System.out.print("Quantas aeromoças deseja adicionar? ");
                    int numAeromocas = sc.nextInt();
                    sc.nextLine();
                    for (int i = 0; i < numAeromocas; i++) {
                        System.out.print("Digite o nome da aeromoça " + (i + 1) + ": ");
                        String nomeAeromoca = sc.nextLine();
                        tripulacao.adicionarAeromoca(new Aeromoca(nomeAeromoca));
                    }
                    
                    break;
                
                case '2':
                    System.out.print("Digite o modelo do avião: ");
                    String modeloAviao = sc.nextLine();
                    System.out.print("Digite o número de lugares no avião: ");
                    int numLugares = sc.nextInt();
                    Aviao aviao = new Aviao(modeloAviao, numLugares);

                    break;

                case '3':
                    System.out.print("Digite o nome do passageiro: ");
                    String nomePassageiro = sc.nextLine();

                    System.out.print("Digite o assento do passageiro: ");
                    int assento = sc.nextInt();
                    sc.nextLine();

                    aviao.ocuparLugar(assento, new Passageiro(nomePassageiro, assento));

                    break;
                
                case '4':
                    System.out.print("Digite o número do voo: ");
                    int numVoo = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Digite o horário do voo: ");
                    String horarioVoo = sc.nextLine();
                    Voo voo = new Voo(numVoo, horarioVoo, aviao, tripulacao);
            
                    aeroporto.adicionarVoo(voo);

                    break;

                case '5':
                    System.out.println("\n=== Voos ===");    
                    aeroporto.listarVoos();
                    break;

                case '6':
                    boolean found = false;

                    System.out.print("Digite o voo em que vai alterar: ");
                    int id = sc.nextInt();
                    sc.nextLine();

                    for (Voo v : voos) {
                        if (id == v.getNumero()) {
                            found = true;
                            v.aterrissar();
                            System.out.println("Voo: " + id + " - aterrissando!");
                            break;
                        }
                    }
                    if(!found){
                        System.out.println("Voo nao encontrado!");
                    }

                    break;

                case '7':
                    System.out.println("\n=== Tripulação ===");
                    tripulacao.listarTripulacao();
                    System.out.println("\n=== Passageiros no Voo ===");
                    voo.listarPassageiros();

                    break;

                default:
                    System.out.println("Opcao invalida!");
                    break;
            }
        }

        System.out.println("Encerrando programa...");
        sc.close();
    }
}
