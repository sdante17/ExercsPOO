package Aeroporto;

class Passageiro {
    private String nome;
    private int numAssento;

    public Passageiro(String nome, int numAssento) {
        this.nome = nome;
        this.numAssento = numAssento;
    }

    public String getNome() {
        return nome;
    }
}