package Aeroporto;

import java.util.ArrayList;
import java.util.List;

public class Tripulacao {
    private Piloto piloto;
    private CoPiloto coPiloto;
    private List<Aeromoca> aeromocas;

    public Tripulacao(Piloto piloto, CoPiloto coPiloto) {
        this.piloto = piloto;
        this.coPiloto = coPiloto;
        this.aeromocas = new ArrayList<>();
    }

    public void adicionarAeromoca(Aeromoca aeromoca) {
        aeromocas.add(aeromoca);
    }

    public void listarTripulacao() {
        System.out.println("Piloto: " + piloto.getNome());
        System.out.println("Co-Piloto: " + coPiloto.getNome());
        for (Aeromoca aeromoca : aeromocas) {
            System.out.println("Aeromoça: " + aeromoca.getNome());
        }
    }
}